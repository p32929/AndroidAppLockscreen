package p32929.easypasscodelock.Interfaces;

/**
 * Created by p32929 on 7/17/2018.
 */

public interface ActivityChanger {
    void activityClass(Class activityClassToGo);
}
